<div class="links">
    <a href="/upload">Upload</a>
    <a href="/queues">Queue tutorial</a>
    <a href="/hello">Hello</a>
    <a href="https://github.com/amezmo/demo.amezmo.com">Source code</a>
    <a href="/posts/new">Database Tutorial</a>
    <a href="https://docs.amezmo.com">Amezmo Docs</a>
</div>
<div>
    <div>Storage path: {{ storage_path() }}</div>
    <div>Public path: {{ storage_path('app/public') }}</div>
</div>