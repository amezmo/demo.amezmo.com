<div class="top-right links">
    <a href="{{ url('/home') }}">demo.amezmo.com</a>
</div>
